# ListAI Pro 🚀

**AI-Powered eBay Listing Generator** — Create professional, keyword-rich eBay listings in seconds using Claude AI.

## Features

- ⚡ AI-generated titles, descriptions & keywords
- 📊 Listing history dashboard
- 💰 Free / Pro / Agency pricing plans
- 📱 Fully responsive design
- 🔍 SEO-optimized listings

## Getting Started

### Install dependencies
```bash
npm install
```

### Run locally
```bash
npm start
```

### Build for production
```bash
npm run build
```

## Deploy on Vercel

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click **"New Project"** → Import your GitHub repo
4. Click **Deploy** — done!

## Tech Stack

- React 18
- Claude AI (Anthropic API)
- Pure CSS-in-JS (no external UI library)

## License

MIT
