import { useState, useEffect } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const CATEGORIES = [
  "Electronics","Clothing & Accessories","Home & Garden","Toys & Hobbies",
  "Sports & Outdoors","Books","Automotive","Jewelry & Watches",
  "Collectibles","Health & Beauty","Musical Instruments","Other"
];
const CONDITIONS = ["New","Like New","Very Good","Good","Acceptable"];
const FREE_LIMIT = 3;
const PLANS = {
  free:  { name: "Free",    price: 0,   listings: 3,         color: "#555" },
  pro:   { name: "Pro",     price: 9,   listings: "Unlimited", color: "#6c63ff" },
  agency:{ name: "Agency",  price: 29,  listings: "Unlimited", color: "#f5af02" },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2, 9);
const now = () => new Date().toLocaleDateString("en-PK", { day:"numeric", month:"short", year:"numeric" });

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage]         = useState("landing"); // landing | app | pricing | dashboard
  const [plan, setPlan]         = useState("free");
  const [usedCount, setUsedCount] = useState(0);
  const [history, setHistory]   = useState([]);
  const [toast, setToast]       = useState(null);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  };

  const canGenerate = plan !== "free" || usedCount < FREE_LIMIT;

  const onListingCreated = (listing) => {
    setUsedCount(c => c + 1);
    setHistory(h => [{ id: uid(), date: now(), title: listing.title, listing }, ...h]);
    showToast("Listing successfully generated!");
  };

  return (
    <div style={S.root}>
      <style>{CSS}</style>
      {toast && <Toast msg={toast.msg} type={toast.type} />}
      <Nav page={page} setPage={setPage} plan={plan} />
      {page === "landing"   && <Landing   setPage={setPage} />}
      {page === "app"       && <Generator canGenerate={canGenerate} plan={plan} usedCount={usedCount} onCreated={onListingCreated} setPage={setPage} showToast={showToast} />}
      {page === "pricing"   && <Pricing   plan={plan} setPlan={setPlan} setPage={setPage} showToast={showToast} />}
      {page === "dashboard" && <Dashboard history={history} plan={plan} usedCount={usedCount} setPage={setPage} />}
    </div>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
function Nav({ page, setPage, plan }) {
  return (
    <nav style={S.nav}>
      <div style={S.navLogo} onClick={() => setPage("landing")}>
        <span style={S.navLogoMark}>L</span>
        <span style={S.navBrand}>ListAI <span style={{ color:"#6c63ff" }}>Pro</span></span>
      </div>
      <div style={S.navLinks}>
        {[["app","Generator"],["pricing","Pricing"],["dashboard","Dashboard"]].map(([p,label]) => (
          <button key={p} style={{ ...S.navLink, ...(page===p ? S.navLinkActive : {}) }} onClick={() => setPage(p)}>
            {label}
          </button>
        ))}
      </div>
      <div style={S.planBadge}>{PLANS[plan].name} Plan</div>
    </nav>
  );
}

// ─── Landing ──────────────────────────────────────────────────────────────────
function Landing({ setPage }) {
  const features = [
    { icon: "⚡", title: "AI-Powered Titles", desc: "SEO-optimized 80-char titles that rank higher in eBay search results." },
    { icon: "📝", title: "Full Descriptions", desc: "Persuasive, buyer-ready descriptions written in seconds." },
    { icon: "🔍", title: "Smart Keywords", desc: "10 targeted search tags per listing to maximize visibility." },
    { icon: "📦", title: "Shipping Tips", desc: "Smart packaging suggestions to reduce returns and disputes." },
    { icon: "📊", title: "Listing History", desc: "All your listings saved — revisit, copy, and reuse anytime." },
    { icon: "💡", title: "Pro Seller Tips", desc: "Insider advice to sell faster and command better prices." },
  ];
  const stats = [{ n:"50K+", l:"Listings Created" },{ n:"98%", l:"Satisfaction Rate" },{ n:"3x", l:"Faster than Manual" }];

  return (
    <div>
      {/* Hero */}
      <section style={S.hero}>
        <div style={S.heroGlow} />
        <div style={S.heroContent}>
          <div style={S.heroBadge}>🚀 AI-Powered eBay Tool</div>
          <h1 style={S.heroH1}>
            Create Winning<br />
            <span style={S.heroGradText}>eBay Listings</span><br />
            in Seconds
          </h1>
          <p style={S.heroSub}>
            Stop spending hours writing listings. Our AI generates professional, keyword-rich eBay listings that sell — instantly.
          </p>
          <div style={S.heroBtns}>
            <button style={S.btnPrimary} onClick={() => setPage("app")}>
              Try Free — No Signup
            </button>
            <button style={S.btnGhost} onClick={() => setPage("pricing")}>
              See Pricing →
            </button>
          </div>
          <div style={S.heroStats}>
            {stats.map(s => (
              <div key={s.n} style={S.heroStat}>
                <span style={S.heroStatN}>{s.n}</span>
                <span style={S.heroStatL}>{s.l}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={S.section}>
        <div style={S.sectionHead}>
          <div style={S.eyebrow}>What You Get</div>
          <h2 style={S.sectionH2}>Everything a Power Seller Needs</h2>
        </div>
        <div style={S.featGrid}>
          {features.map(f => (
            <div key={f.title} style={S.featCard}>
              <div style={S.featIcon}>{f.icon}</div>
              <div style={S.featTitle}>{f.title}</div>
              <div style={S.featDesc}>{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={S.ctaSection}>
        <h2 style={S.ctaH2}>Start Listing Smarter Today</h2>
        <p style={S.ctaSub}>Free plan includes 3 listings. No credit card required.</p>
        <button style={S.btnPrimary} onClick={() => setPage("app")}>Create Your First Listing →</button>
      </section>

      <footer style={S.footer}>
        <span>© 2025 ListAI Pro</span>
        <span style={{ color:"#444" }}>Powered by Claude AI</span>
      </footer>
    </div>
  );
}

// ─── Generator ────────────────────────────────────────────────────────────────
function Generator({ canGenerate, plan, usedCount, onCreated, setPage, showToast }) {
  const [form, setForm]     = useState({ productName:"", category:"", condition:"", keyFeatures:"", price:"", location:"" });
  const [state, setState]   = useState("form"); // form | loading | result
  const [listing, setListing] = useState(null);
  const [error, setError]   = useState("");
  const [copied, setCopied] = useState(null);

  const copy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    showToast("Copied to clipboard!");
    setTimeout(() => setCopied(null), 2000);
  };

  const generate = async () => {
    if (!canGenerate) { setPage("pricing"); return; }
    if (!form.productName || !form.category || !form.condition) {
      setError("Product Name, Category aur Condition zaroori hain."); return;
    }
    setError(""); setState("loading");

    const prompt = `You are an expert eBay seller copywriter. Generate a professional eBay product listing.
Product: ${form.productName}
Category: ${form.category}
Condition: ${form.condition}
Features: ${form.keyFeatures || "Not provided"}
Price: ${form.price ? "$"+form.price : "Not specified"}
Location: ${form.location || "Not specified"}

Return ONLY valid JSON, no markdown, no explanation:
{
  "title": "Optimized eBay title max 80 chars keyword-rich",
  "subtitle": "Catchy subtitle max 55 chars",
  "description": "Full persuasive HTML listing description 3 paragraphs with <b> tags for emphasis",
  "bulletPoints": ["5 key selling points as short strings"],
  "searchTags": ["10 relevant eBay search keywords"],
  "shippingNote": "Practical shipping and packaging tip",
  "sellerTip": "One actionable pro tip to sell faster or at higher price"
}`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:1000,
          messages:[{ role:"user", content:prompt }]
        })
      });
      const data = await res.json();
      const text = data.content.map(i=>i.text||"").join("");
      const parsed = JSON.parse(text.replace(/```json|```/g,"").trim());
      setListing(parsed);
      onCreated(parsed);
      setState("result");
    } catch {
      setError("Kuch masla aaya, dobara try karein.");
      setState("form");
    }
  };

  const reset = () => { setState("form"); setListing(null); setForm({ productName:"",category:"",condition:"",keyFeatures:"",price:"",location:"" }); };

  const remaining = FREE_LIMIT - usedCount;

  return (
    <div style={S.pageWrap}>
      {/* Usage bar */}
      {plan === "free" && (
        <div style={S.usageBar}>
          <span>Free Plan: <b>{remaining > 0 ? remaining : 0}</b> listings remaining</span>
          <button style={S.upgradeChip} onClick={() => setPage("pricing")}>Upgrade to Pro →</button>
        </div>
      )}

      {state === "form" && (
        <div style={S.card}>
          <h2 style={S.cardTitle}>Generate eBay Listing</h2>
          <p style={S.cardSub}>Product ki details bharo — AI baaki kaam karega</p>

          <div style={S.formRow}>
            <div style={{ flex:1 }}>
              <label style={S.label}>Product Name *</label>
              <input style={S.input} placeholder="e.g. Apple iPhone 14 Pro 256GB" value={form.productName}
                onChange={e=>setForm({...form,productName:e.target.value})} />
            </div>
          </div>

          <div style={S.formGrid}>
            <div>
              <label style={S.label}>Category *</label>
              <select style={S.select} value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
                <option value="">Select category…</option>
                {CATEGORIES.map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={S.label}>Condition *</label>
              <select style={S.select} value={form.condition} onChange={e=>setForm({...form,condition:e.target.value})}>
                <option value="">Select condition…</option>
                {CONDITIONS.map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div style={S.formRow}>
            <div style={{ flex:1 }}>
              <label style={S.label}>Key Features / Details</label>
              <textarea style={S.textarea} rows={3}
                placeholder="e.g. Unlocked, original box, battery 92%, minor scratch on corner"
                value={form.keyFeatures} onChange={e=>setForm({...form,keyFeatures:e.target.value})} />
            </div>
          </div>

          <div style={S.formGrid}>
            <div>
              <label style={S.label}>Asking Price (USD)</label>
              <input style={S.input} type="number" placeholder="e.g. 450"
                value={form.price} onChange={e=>setForm({...form,price:e.target.value})} />
            </div>
            <div>
              <label style={S.label}>Your Location</label>
              <input style={S.input} placeholder="e.g. New York, NY"
                value={form.location} onChange={e=>setForm({...form,location:e.target.value})} />
            </div>
          </div>

          {error && <div style={S.errorBox}>{error}</div>}

          {!canGenerate
            ? <div style={S.limitBox}>
                Free limit reached! <button style={S.upgradeChip} onClick={()=>setPage("pricing")}>Upgrade to Pro →</button>
              </div>
            : <button style={S.btnPrimary} onClick={generate}>✦ Generate Listing with AI</button>
          }
        </div>
      )}

      {state === "loading" && (
        <div style={S.card}>
          <div style={S.loadingWrap}>
            <div style={S.spinner} />
            <p style={S.loadingText}>AI aapki listing bana raha hai…</p>
            <p style={{ color:"#555", fontSize:13 }}>Usually takes 5–10 seconds</p>
          </div>
        </div>
      )}

      {state === "result" && listing && (
        <div style={S.card}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:24 }}>
            <div>
              <h2 style={S.cardTitle}>🎉 Listing Ready!</h2>
              <p style={S.cardSub}>eBay par copy-paste karein</p>
            </div>
            <button style={S.btnGhost} onClick={reset}>+ New Listing</button>
          </div>

          <ResultBlock label="📌 Title" text={listing.title} onCopy={()=>copy(listing.title,"title")} copied={copied==="title"} />
          <ResultBlock label="✏️ Subtitle" text={listing.subtitle} onCopy={()=>copy(listing.subtitle,"sub")} copied={copied==="sub"} />

          <div style={S.resultSection}>
            <div style={S.resultLabel}>⚡ Key Highlights</div>
            <div style={S.resultBox}>
              {(listing.bulletPoints||[]).map((b,i)=>(
                <div key={i} style={S.bullet}><div style={S.bulletDot}/><span style={{ color:"#ccc" }}>{b}</span></div>
              ))}
            </div>
          </div>

          <div style={S.resultSection}>
            <div style={S.resultLabel}>📝 Full Description</div>
            <div style={{ ...S.resultBox, position:"relative", paddingRight:80 }}>
              <div style={{ color:"#ccc", lineHeight:1.7 }} dangerouslySetInnerHTML={{ __html:listing.description }} />
              <button style={S.copyBtn} onClick={()=>copy(listing.description,"desc")}>{copied==="desc"?"✓ Copied":"Copy"}</button>
            </div>
          </div>

          <div style={S.resultSection}>
            <div style={S.resultLabel}>🔍 Search Keywords</div>
            <div style={S.resultBox}>
              {(listing.searchTags||[]).map((t,i)=><span key={i} style={S.tag}>{t}</span>)}
            </div>
          </div>

          {listing.shippingNote && <ResultBlock label="📦 Shipping Tip" text={listing.shippingNote} onCopy={()=>copy(listing.shippingNote,"ship")} copied={copied==="ship"} />}

          {listing.sellerTip && (
            <div style={S.resultSection}>
              <div style={S.resultLabel}>💡 Pro Seller Tip</div>
              <div style={{ ...S.resultBox, borderColor:"rgba(108,99,255,0.3)", background:"rgba(108,99,255,0.07)", color:"#a5a0ff" }}>
                {listing.sellerTip}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ResultBlock({ label, text, onCopy, copied }) {
  return (
    <div style={S.resultSection}>
      <div style={S.resultLabel}>{label}</div>
      <div style={{ ...S.resultBox, paddingRight:90 }}>
        <span style={{ color:"#ccc" }}>{text}</span>
        <button style={S.copyBtn} onClick={onCopy}>{copied?"✓ Copied":"Copy"}</button>
      </div>
    </div>
  );
}

// ─── Pricing ──────────────────────────────────────────────────────────────────
function Pricing({ plan, setPlan, setPage, showToast }) {
  const plans = [
    { key:"free",   emoji:"🌱", listings:"3 listings",       price:"$0",  per:"forever free", features:["AI title & description","10 search keywords","Shipping tips","Basic history (3)"] },
    { key:"pro",    emoji:"⚡", listings:"Unlimited listings", price:"$9", per:"per month",    features:["Everything in Free","Unlimited AI listings","Full listing history","Pro seller tips","Priority generation","Export to CSV"], popular:true },
    { key:"agency", emoji:"🏆", listings:"Unlimited + Team",  price:"$29", per:"per month",   features:["Everything in Pro","5 team members","Bulk generation","API access","White-label option","Dedicated support"] },
  ];

  return (
    <div style={S.pageWrap}>
      <div style={{ textAlign:"center", marginBottom:40 }}>
        <div style={S.eyebrow}>Simple Pricing</div>
        <h2 style={S.sectionH2}>Choose Your Plan</h2>
        <p style={{ color:"#666", fontSize:15 }}>Start free. Upgrade when you're ready.</p>
      </div>
      <div style={S.pricingGrid}>
        {plans.map(p=>(
          <div key={p.key} style={{ ...S.pricingCard, ...(p.popular ? S.pricingCardPop : {}) }}>
            {p.popular && <div style={S.popularBadge}>Most Popular</div>}
            <div style={S.pricingEmoji}>{p.emoji}</div>
            <div style={S.pricingName}>{PLANS[p.key].name}</div>
            <div style={S.pricingPrice}>{p.price}<span style={S.pricingPer}> / {p.per}</span></div>
            <div style={S.pricingListings}>{p.listings}</div>
            <div style={S.pricingDivider}/>
            {p.features.map(f=>(
              <div key={f} style={S.pricingFeature}><span style={{ color:"#6c63ff" }}>✓</span> {f}</div>
            ))}
            <button
              style={{ ...S.btnPrimary, marginTop:24, opacity: plan===p.key ? 0.5 : 1 }}
              onClick={() => {
                if (plan === p.key) return;
                setPlan(p.key);
                showToast(`${PLANS[p.key].name} plan activated!`);
                setPage("app");
              }}
            >
              {plan===p.key ? "Current Plan" : p.key==="free" ? "Get Started Free" : `Upgrade to ${PLANS[p.key].name}`}
            </button>
          </div>
        ))}
      </div>
      <p style={{ textAlign:"center", color:"#444", fontSize:13, marginTop:24 }}>
        🔒 Secure payments · Cancel anytime · No hidden fees
      </p>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ history, plan, usedCount, setPage }) {
  const [selected, setSelected] = useState(null);

  return (
    <div style={S.pageWrap}>
      <div style={S.dashHeader}>
        <div>
          <h2 style={S.cardTitle}>Your Dashboard</h2>
          <p style={S.cardSub}>Saari listings ek jagah</p>
        </div>
        <button style={S.btnPrimary} onClick={() => setPage("app")}>+ New Listing</button>
      </div>

      {/* Stats */}
      <div style={S.statsGrid}>
        {[
          { label:"Total Listings", value: history.length },
          { label:"Plan", value: PLANS[plan].name },
          { label:"This Month", value: usedCount },
          { label:"Remaining", value: plan==="free" ? Math.max(0, FREE_LIMIT - usedCount) : "∞" },
        ].map(s=>(
          <div key={s.label} style={S.statCard}>
            <div style={S.statVal}>{s.value}</div>
            <div style={S.statLabel}>{s.label}</div>
          </div>
        ))}
      </div>

      {history.length === 0
        ? <div style={S.emptyState}>
            <div style={{ fontSize:48 }}>📋</div>
            <p style={{ color:"#555", marginTop:12 }}>Abhi tak koi listing nahi bani.</p>
            <button style={{ ...S.btnPrimary, width:"auto", padding:"10px 28px", marginTop:12 }} onClick={() => setPage("app")}>
              Pehli Listing Banao
            </button>
          </div>
        : <div>
            {history.map(h=>(
              <div key={h.id} style={S.historyRow} onClick={() => setSelected(selected===h.id ? null : h.id)}>
                <div style={{ flex:1 }}>
                  <div style={{ color:"#e0e0f0", fontWeight:600, fontSize:14 }}>{h.title}</div>
                  <div style={{ color:"#555", fontSize:12, marginTop:3 }}>{h.date}</div>
                </div>
                <span style={{ color:"#6c63ff", fontSize:12 }}>{selected===h.id ? "▲ Hide" : "▼ View"}</span>
              </div>
            ))}
            {selected && (() => {
              const h = history.find(x=>x.id===selected);
              if (!h) return null;
              return (
                <div style={{ ...S.card, marginTop:0, borderTop:"none", borderRadius:"0 0 16px 16px" }}>
                  <div style={{ color:"#a0a0cc", fontSize:13, lineHeight:1.8 }}>
                    <b style={{ color:"#f5af02" }}>Title:</b> {h.listing.title}<br/>
                    <b style={{ color:"#f5af02" }}>Tags:</b> {(h.listing.searchTags||[]).join(", ")}<br/>
                    <b style={{ color:"#f5af02" }}>Tip:</b> {h.listing.sellerTip}
                  </div>
                </div>
              );
            })()}
          </div>
      }
    </div>
  );
}

// ─── Toast ────────────────────────────────────────────────────────────────────
function Toast({ msg, type }) {
  return (
    <div style={{ ...S.toast, background: type==="error" ? "#c0392b" : "#6c63ff" }}>
      {msg}
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  root: { minHeight:"100vh", background:"#0a0a0f", fontFamily:"'Inter','Segoe UI',system-ui,sans-serif", color:"#fff" },

  // Nav
  nav: { display:"flex", alignItems:"center", padding:"14px 28px", borderBottom:"1px solid #1a1a2e", background:"rgba(10,10,15,0.95)", position:"sticky", top:0, zIndex:100, gap:16 },
  navLogo: { display:"flex", alignItems:"center", gap:10, cursor:"pointer" },
  navLogoMark: { width:34, height:34, background:"linear-gradient(135deg,#6c63ff,#a78bfa)", borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:900, fontSize:18, flexShrink:0 },
  navBrand: { fontWeight:800, fontSize:17, letterSpacing:-0.5 },
  navLinks: { display:"flex", gap:4, marginLeft:"auto" },
  navLink: { background:"none", border:"none", color:"#666", fontSize:14, fontWeight:500, cursor:"pointer", padding:"6px 14px", borderRadius:8, transition:"all 0.15s" },
  navLinkActive: { color:"#a5a0ff", background:"rgba(108,99,255,0.12)" },
  planBadge: { background:"rgba(108,99,255,0.15)", border:"1px solid rgba(108,99,255,0.3)", color:"#a5a0ff", fontSize:11, fontWeight:700, padding:"4px 10px", borderRadius:20 },

  // Landing Hero
  hero: { position:"relative", textAlign:"center", padding:"90px 20px 80px", overflow:"hidden" },
  heroGlow: { position:"absolute", top:"20%", left:"50%", transform:"translateX(-50%)", width:600, height:600, background:"radial-gradient(circle, rgba(108,99,255,0.15) 0%, transparent 70%)", pointerEvents:"none" },
  heroContent: { position:"relative", maxWidth:640, margin:"0 auto" },
  heroBadge: { display:"inline-block", background:"rgba(108,99,255,0.15)", border:"1px solid rgba(108,99,255,0.3)", color:"#a5a0ff", padding:"6px 16px", borderRadius:20, fontSize:13, fontWeight:600, marginBottom:24 },
  heroH1: { fontSize:"clamp(36px,6vw,64px)", fontWeight:800, lineHeight:1.1, letterSpacing:-2, margin:"0 0 20px" },
  heroGradText: { background:"linear-gradient(90deg,#6c63ff,#a78bfa,#f5af02)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" },
  heroSub: { fontSize:17, color:"#777", lineHeight:1.6, marginBottom:36, maxWidth:480, margin:"0 auto 36px" },
  heroBtns: { display:"flex", gap:14, justifyContent:"center", flexWrap:"wrap", marginBottom:48 },
  heroStats: { display:"flex", justifyContent:"center", gap:40, flexWrap:"wrap" },
  heroStat: { display:"flex", flexDirection:"column", alignItems:"center" },
  heroStatN: { fontSize:28, fontWeight:800, background:"linear-gradient(90deg,#6c63ff,#a78bfa)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" },
  heroStatL: { fontSize:12, color:"#555", marginTop:2 },

  // Sections
  section: { maxWidth:960, margin:"0 auto", padding:"60px 24px" },
  sectionHead: { textAlign:"center", marginBottom:48 },
  sectionH2: { fontSize:"clamp(24px,4vw,38px)", fontWeight:800, letterSpacing:-1, margin:"8px 0 0" },
  eyebrow: { display:"inline-block", background:"rgba(108,99,255,0.15)", color:"#a5a0ff", padding:"4px 14px", borderRadius:20, fontSize:12, fontWeight:700, letterSpacing:1, textTransform:"uppercase" },
  featGrid: { display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))", gap:20 },
  featCard: { background:"#111118", border:"1px solid #1e1e30", borderRadius:16, padding:"24px 22px" },
  featIcon: { fontSize:28, marginBottom:12 },
  featTitle: { fontWeight:700, fontSize:15, marginBottom:6 },
  featDesc: { color:"#666", fontSize:13, lineHeight:1.6 },

  // CTA
  ctaSection: { textAlign:"center", padding:"80px 20px", background:"linear-gradient(135deg,rgba(108,99,255,0.08),rgba(167,139,250,0.05))", borderTop:"1px solid #1a1a2e", borderBottom:"1px solid #1a1a2e" },
  ctaH2: { fontSize:"clamp(24px,4vw,40px)", fontWeight:800, letterSpacing:-1, marginBottom:12 },
  ctaSub: { color:"#666", fontSize:15, marginBottom:32 },

  footer: { display:"flex", justifyContent:"space-between", padding:"20px 32px", borderTop:"1px solid #111", fontSize:12, color:"#333" },

  // Page wrapper
  pageWrap: { maxWidth:780, margin:"0 auto", padding:"36px 20px" },

  // Cards
  card: { background:"#111118", border:"1px solid #1e1e30", borderRadius:20, padding:"32px 28px", marginBottom:20 },
  cardTitle: { fontSize:22, fontWeight:800, letterSpacing:-0.5, marginBottom:4 },
  cardSub: { color:"#555", fontSize:13, marginBottom:28 },

  // Forms
  formRow: { display:"flex", gap:16, marginBottom:16 },
  formGrid: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 },
  label: { display:"block", fontSize:11, fontWeight:700, color:"#555", marginBottom:6, textTransform:"uppercase", letterSpacing:0.8 },
  input: { width:"100%", background:"#0d0d14", border:"1px solid #1e1e30", borderRadius:10, padding:"11px 14px", color:"#e0e0f0", fontSize:14, boxSizing:"border-box", outline:"none" },
  select: { width:"100%", background:"#0d0d14", border:"1px solid #1e1e30", borderRadius:10, padding:"11px 14px", color:"#e0e0f0", fontSize:14, boxSizing:"border-box", outline:"none" },
  textarea: { width:"100%", background:"#0d0d14", border:"1px solid #1e1e30", borderRadius:10, padding:"11px 14px", color:"#e0e0f0", fontSize:14, boxSizing:"border-box", outline:"none", resize:"vertical", fontFamily:"inherit" },

  // Buttons
  btnPrimary: { display:"block", width:"100%", padding:"13px 24px", background:"linear-gradient(90deg,#6c63ff,#a78bfa)", border:"none", borderRadius:12, color:"#fff", fontWeight:700, fontSize:15, cursor:"pointer", letterSpacing:0.2 },
  btnGhost: { background:"rgba(255,255,255,0.06)", border:"1px solid #2a2a40", borderRadius:12, color:"#aaa", fontWeight:600, fontSize:14, cursor:"pointer", padding:"10px 20px" },

  // Result
  resultSection: { marginBottom:18 },
  resultLabel: { fontSize:11, fontWeight:700, color:"#6c63ff", textTransform:"uppercase", letterSpacing:1, marginBottom:8 },
  resultBox: { background:"#0d0d14", border:"1px solid #1e1e30", borderRadius:12, padding:"14px 16px", position:"relative" },
  copyBtn: { position:"absolute", top:10, right:10, background:"rgba(108,99,255,0.15)", border:"1px solid rgba(108,99,255,0.3)", borderRadius:7, padding:"4px 12px", color:"#a5a0ff", fontSize:11, cursor:"pointer", fontWeight:700 },
  bullet: { display:"flex", gap:10, alignItems:"flex-start", marginBottom:8 },
  bulletDot: { width:6, height:6, borderRadius:"50%", background:"linear-gradient(135deg,#6c63ff,#a78bfa)", marginTop:7, flexShrink:0 },
  tag: { display:"inline-block", background:"rgba(245,175,2,0.1)", border:"1px solid rgba(245,175,2,0.2)", color:"#f5c842", borderRadius:20, padding:"3px 12px", fontSize:12, marginRight:6, marginBottom:6 },

  // Usage
  usageBar: { display:"flex", alignItems:"center", justifyContent:"space-between", background:"rgba(108,99,255,0.08)", border:"1px solid rgba(108,99,255,0.2)", borderRadius:12, padding:"10px 18px", marginBottom:20, fontSize:13, color:"#a5a0ff" },
  upgradeChip: { background:"linear-gradient(90deg,#6c63ff,#a78bfa)", border:"none", borderRadius:20, color:"#fff", fontWeight:700, fontSize:12, cursor:"pointer", padding:"5px 14px" },
  limitBox: { background:"rgba(245,175,2,0.08)", border:"1px solid rgba(245,175,2,0.25)", borderRadius:12, padding:"14px 18px", color:"#f5c842", fontSize:14, display:"flex", alignItems:"center", gap:14, marginTop:20 },
  errorBox: { background:"rgba(192,57,43,0.1)", border:"1px solid rgba(192,57,43,0.3)", borderRadius:10, padding:"10px 14px", color:"#e74c3c", fontSize:13, marginTop:12 },

  // Loading
  loadingWrap: { display:"flex", flexDirection:"column", alignItems:"center", padding:"60px 0", gap:16 },
  spinner: { width:44, height:44, border:"3px solid #1e1e30", borderTop:"3px solid #6c63ff", borderRadius:"50%", animation:"spin 0.8s linear infinite" },
  loadingText: { color:"#888", fontSize:15 },

  // Pricing
  pricingGrid: { display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", gap:20, maxWidth:860, margin:"0 auto" },
  pricingCard: { background:"#111118", border:"1px solid #1e1e30", borderRadius:20, padding:"28px 24px", position:"relative" },
  pricingCardPop: { border:"1px solid rgba(108,99,255,0.5)", background:"rgba(108,99,255,0.05)" },
  popularBadge: { position:"absolute", top:-12, left:"50%", transform:"translateX(-50%)", background:"linear-gradient(90deg,#6c63ff,#a78bfa)", color:"#fff", fontSize:11, fontWeight:700, padding:"4px 14px", borderRadius:20 },
  pricingEmoji: { fontSize:32, marginBottom:12 },
  pricingName: { fontWeight:700, fontSize:16, marginBottom:4 },
  pricingPrice: { fontSize:34, fontWeight:800, letterSpacing:-1, marginBottom:2 },
  pricingPer: { fontSize:14, fontWeight:400, color:"#555" },
  pricingListings: { color:"#6c63ff", fontSize:13, fontWeight:600, marginBottom:16 },
  pricingDivider: { height:1, background:"#1e1e30", margin:"16px 0" },
  pricingFeature: { fontSize:13, color:"#888", marginBottom:8, display:"flex", gap:8 },

  // Dashboard
  dashHeader: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:28 },
  statsGrid: { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:28 },
  statCard: { background:"#111118", border:"1px solid #1e1e30", borderRadius:14, padding:"18px 16px", textAlign:"center" },
  statVal: { fontSize:28, fontWeight:800, background:"linear-gradient(90deg,#6c63ff,#a78bfa)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" },
  statLabel: { fontSize:11, color:"#555", marginTop:4, textTransform:"uppercase", letterSpacing:0.8 },
  historyRow: { background:"#111118", border:"1px solid #1e1e30", borderRadius:12, padding:"16px 20px", marginBottom:10, display:"flex", alignItems:"center", cursor:"pointer" },
  emptyState: { textAlign:"center", padding:"60px 20px", color:"#fff" },

  // Toast
  toast: { position:"fixed", bottom:28, right:28, padding:"12px 22px", borderRadius:12, color:"#fff", fontWeight:600, fontSize:14, zIndex:999, boxShadow:"0 8px 32px rgba(0,0,0,0.4)" },
};

const CSS = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  @keyframes spin { to { transform: rotate(360deg); } }
  input:focus, textarea:focus, select:focus { border-color: rgba(108,99,255,0.5) !important; outline: none; }
  input::placeholder, textarea::placeholder { color: #333 !important; }
  button { font-family: inherit; }
  @media (max-width: 600px) {
    [style*="gridTemplateColumns: repeat(4"] { grid-template-columns: repeat(2,1fr) !important; }
    [style*="gridTemplateColumns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
  }
`;
